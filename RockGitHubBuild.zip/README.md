# Rock — phone-only APK build

This project is prepared for GitHub Actions.

1. Create/sign in to GitHub.
2. Create a new repository named Rock.
3. Upload all files from this folder.
4. Open the repository's Actions tab.
5. Select Build Rock APK.
6. Tap Run workflow.
7. When it finishes, open the run and download the Rock-APK artifact.
8. Extract it and install app-debug.apk on your Android phone.

The included Android app uses Android speech recognition and Text-to-Speech.
The backend folder is a starter and requires an API key and a reachable server.
Do not put an AI API key inside the Android APK.
